# Terraform deployment for Orbit INFRA-DEV

## Description

We have used Nested Terraform Module Structure here.

Child Modules are :
  - Resource Group
  - Network Security Group
  - Virtual Network
  - Storage Account
  - Cosmos db
  - Load balancers
  - Virtual Machine scale set
  - Function app

To that end, we have split the Azure services into small, tightly focused units (i.e. Terraform modules) and then, it assembles them as a Terraform configuration (or root module).