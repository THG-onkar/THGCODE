This **Terraform** module deploys azure storage account with two service endpoints resource.
