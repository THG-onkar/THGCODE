This **Terraform** module deploys Four azure load balancer resources :  
  - Three internal load balancers.
  - Single public load balancer.